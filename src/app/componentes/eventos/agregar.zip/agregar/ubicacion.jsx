'use client';
import React, { useState, useCallback, useEffect } from 'react';
import { GoogleMap, Marker, LoadScriptNext } from '@react-google-maps/api';

const UbicacionEvento = ({ siguientePaso, anteriorPaso, handleUpdateData, eventoData }) => {
  const [ubicacion, setUbicacion] = useState({
    lat: -16.5,
    lng: -68.15,
  });
  const [direccion, setDireccion] = useState('');
  const [departamento, setDepartamento] = useState('');
  const [descripcion, setDescripcion] = useState('');

  // Si hay datos previos en eventoData, cargarlos en los estados
  useEffect(() => {
    if (eventoData && eventoData.ubicacion) {
      setDireccion(eventoData.ubicacion.direccion || '');
      setDepartamento(eventoData.ubicacion.departamento || '');
      setDescripcion(eventoData.ubicacion.descripcion || '');
    }
  }, [eventoData]);

  const handleMapClick = useCallback((event) => {
    const nuevaUbicacion = {
      lat: event.latLng.lat(),
      lng: event.latLng.lng(),
    };
    setUbicacion(nuevaUbicacion);
    getDireccion(nuevaUbicacion);
  }, []);

  const getDireccion = async (location) => {
    if (!window.google || !window.google.maps) {
      console.error('Google Maps aún no está disponible');
      return;
    }

    const geocoder = new window.google.maps.Geocoder();
    const latLng = new window.google.maps.LatLng(location.lat, location.lng);

    geocoder.geocode({ location: latLng }, (results, status) => {
      if (status === 'OK') {
        setDireccion(results[0]?.formatted_address || '');
      } else {
        console.error('No se pudo obtener la dirección');
      }
    });
  };

  // Manejar el cambio del select de departamento
  const handleDepartamentoChange = (e) => {
    const selectedDepartamento = e.target.value;
    setDepartamento(selectedDepartamento);
    // Guardar en el estado global
    handleUpdateData('ubicacion', { 
      latLng: ubicacion, 
      direccion, 
      departamento: selectedDepartamento,
      descripcion 
    });
  };

  // Manejar el cambio de descripcion
  const handleDescripcionChange = (e) => {
    const nuevaDescripcion = e.target.value;
    setDescripcion(nuevaDescripcion);
    // Guardar en el estado global
    handleUpdateData('ubicacion', { 
      latLng: ubicacion, 
      direccion, 
      departamento,
      descripcion: nuevaDescripcion
    });
  };

  return (
    <LoadScriptNext googleMapsApiKey="AIzaSyA4coShq7smfTIjc5MwT9JUTs6_uTv07lA">
      <div className="p-4">
        <form className="bg-white p-5 rounded-lg shadow-lg">
          {/* Campo departamento */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Departamento</label>
            <select
              id="departamento"
              value={departamento}
              onChange={handleDepartamentoChange}
              className="w-full p-2 border border-gray-300 rounded-md"
            >
              <option value="La Paz">La Paz</option>
              <option value="Oruro">Oruro</option>
              <option value="Potosi">Potosi</option>
              <option value="Cochabamba">Cochabamba</option>
              <option value="Chuquisaca">Chuquisaca</option>
              <option value="Tarija">Tarija</option>
              <option value="Pando">Pando</option>
              <option value="Beni">Beni</option>
              <option value="Santa Cruz">Santa Cruz</option>
            </select>
          </div>

          {/* Campo dirección */}
          <div className="mb-4">
            <label htmlFor="ubicacion" className="block text-sm font-medium text-gray-700">Ubicación</label>
            <input
              type="text"
              id="ubicacion"
              value={direccion}
              onChange={(e) => setDireccion(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md"
              disabled
            />
          </div>

          {/* Mapa de Google */}
          <GoogleMap
            mapContainerStyle={{ width: '100%', height: '400px' }}
            center={ubicacion}
            zoom={10}
            onClick={handleMapClick}
          >
            <Marker position={ubicacion} />
          </GoogleMap>

          {/* Campo descripción */}
          <div className="mb-4">
            <label htmlFor="descripcion" className="block text-sm font-medium text-gray-700">Descripción</label>
            <input
              type="text"
              id="descripcion"
              value={descripcion}
              onChange={handleDescripcionChange}
              className="w-full p-2 border border-gray-300 rounded-md"
            />
          </div>

          {/* Botones */}
          <div className="flex justify-between mt-4">
            <button
              type="button"
              onClick={anteriorPaso}
              className="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-orange-500"
            >
              Volver
            </button>
            <button
              type="button"
              onClick={() => {
                handleUpdateData('ubicacion', { 
                  latLng: ubicacion, 
                  direccion, 
                  departamento,
                  descripcion
                });
                siguientePaso();
              }}
              className="bg-green-500 text-white py-2 px-4 rounded-full hover:bg-yellow-400"
            >
              Siguiente
            </button>
          </div>
        </form>
      </div>
    </LoadScriptNext>
  );
};

export default UbicacionEvento;
