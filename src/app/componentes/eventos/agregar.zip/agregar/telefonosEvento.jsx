'use client';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

const TelefonosEvento = ({ siguientePaso, anteriorPaso, handleUpdateData, eventoData }) => {
  const [telefonosAgregados, setTelefonosAgregados] = useState(eventoData.telefonos || []);
  const [mostrarAgregar, setMostrarAgregar] = useState(false);
  const [nuevoTelefono, setNuevoTelefono] = useState({
    numero: '',
    nombre: ''
  });

  const router = useRouter();

  const handleAgregarTelefono = () => {
    if (!nuevoTelefono.numero || !nuevoTelefono.nombre) return; // Validar que el nombre y especialidad estén completos
  
    // Evitar agregar expositores repetidos
    if (!telefonosAgregados.some(telofono => telofono.nombre === nuevoTelefono.nombre && telofono.numero === nuevoTelefono.numero)) {
      setNuevoTelefono({ numero: '', nombre: ''}); // Limpiar campos
      const nuevosTelefonos = [...telefonosAgregados, nuevoTelefono];
      setTelefonosAgregados(nuevosTelefonos);
      
      // Llamar a handleUpdateData después de actualizar el estado
      handleUpdateData('telefonos', nuevosTelefonos);
      }
  };
    
  

  const handleQuitarTelefono = (index) => {
    const nuevosTelefonos = telefonosAgregados.filter((_, i) => i !== index);
    // Actualizar el estado de los patrocinadores añadidos
    setTelefonosAgregados(nuevosTelefonos);
    // Actualizar los datos globales mediante handleUpdateData
    handleUpdateData('telefonos', nuevosTelefonos);
  };

  // Manejo de cambios en el formulario de nuevo patrocinador
  const handleNuevoTelefonoChange = (e) => {
    const { name, value } = e.target;
    setNuevoTelefono({ ...nuevoTelefono, [name]: value });
  };

  // Enviar nuevo patrocinador al backend y actualizar la lista en tiempo real
  const handleAgregarNuevoExpositor = async () => {
    try {
      const res = await fetch('https://inf281-production.up.railway.app/eventos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(nuevoTelefono),
      });

      if (!res.ok) throw new Error('Error al agregar el patrocinador');

      const nuevoPatrocinadorRespuesta = await res.json();
      setNuevoTelefono({
        nombre: '',
        especialidad: '',
        institucion: '',
        contacto: ''
      });

      alert('✅ Patrocinador agregado exitosamente!');
      setMostrarAgregar(false);
    } catch (error) {
      console.error('Error al agregar patrocinador:', error);
      alert('❌ Ocurrió un error al agregar el patrocinador.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <form className="bg-white p-5 rounded-lg shadow-lg">


        {/* Formulario para agregar nuevo patrocinador */}
        <div className="mb-4 flex justify-center">
            <button
                type="button"
                onClick={() => setMostrarAgregar(true)}
                className="bg-orange-500 text-white py-2 px-4 rounded-full hover:bg-green-400"
            >
                Crear Nuevo Telefono
            </button>
        </div>
        {/* Mostrar formulario de nuevo patrocinador */}
        {mostrarAgregar && (
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-700">Nuevo Telefono</h3>
            <input
              type="text"
              name="numero"
              value={nuevoTelefono.numero}
              onChange={handleNuevoTelefonoChange}
              placeholder="Número"
              className="w-full p-2 border border-gray-300 rounded-md mb-2"
            />
            <input
              type="text"
              name="nombre"
              value={nuevoTelefono.nombre}
              onChange={handleNuevoTelefonoChange}
              placeholder="Nombre"
              className="w-full p-2 border border-gray-300 rounded-md mb-2"
            />
            <div className='flex justify-center'>
                <button
                type="button"
                onClick={handleAgregarTelefono}
                className="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-green-400"
                >
                Guardar Telefono
                </button>
            </div>
          </div>
        )}

        {/* Mostrar patrocinadores añadidos */}
        <div className="mb-4">
          <h3 className="text-sm font-medium text-gray-700">Telefono Añadidos</h3>
          <ul>
            {telefonosAgregados.map((telefono, index) => (
                <li key={index} className="flex justify-between items-center mb-2">
                    <span>{telefono.nombre} - {telefono.numero}</span> {/* Usamos nombre y especialidad */}
                    <button
                    type="button"
                    onClick={() => handleQuitarTelefono(index)}
                    className="bg-red-500 text-white py-1 px-3 rounded-full hover:bg-red-400"
                    >
                    Eliminar
                    </button>
                </li>
            ))}
          </ul>
        </div>

        {/* Botones de navegación */}
        <div className="flex justify-between mt-4">
          <button
            type="button"
            onClick={anteriorPaso}
            className="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-orange-500"
          >
            Volver
          </button>

          <button
            type="button"
            onClick={siguientePaso}
            className="bg-green-500 text-white py-2 px-4 rounded-full hover:bg-yellow-400"
          >
            Siguiente
          </button>
        </div>

      </form>
    </div>
  );
};

export default TelefonosEvento;
